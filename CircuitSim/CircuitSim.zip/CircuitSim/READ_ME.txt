#READ_ME.txt
#Student Name: Christopher Thomas
#CWID: 11652560


# Purpose of READ_ME.txt
# Names of the .txt docs for each problem


#given: NAND.txt

1: AND.txt OR.txt NOT.txt XOR.txt NOR.txt
2: Q2.txt && Q2test.txt
3: FULLADDER.txt && fulladderTEST.txt
4: RCAwCO_8Bit.txt
5: CSA_8Bit.txt && CSA_multiplexer.txt
6: MC_8Bit.txt && MCShifter.txt
7: S_1Bit.txt
8: M_4Bit.txt
9: D_3to8.txt && d3to8test.txt
10: ANDGate_4Bit.txt
11: S_32Bit.txt
12: RS.txt && RS_1Bit.txt && RS_2Bit.txt && RS_4Bit.txt && RS_8Bit.txt
		ALU_1Bit.txt
13: ALU_4Bit.txt

?: ShifterAdder.txt
